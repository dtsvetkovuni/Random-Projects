﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraController : MonoBehaviour {
	public GameObject Player;
	private Vector3 offset;
	Vector3 temp;

	// Use this for initialization
	void Start () {
		offset = transform.position - Player.transform.position;
	}
	
	// Update is called once per frame
	void LateUpdate () {
		temp = Player.transform.localScale;
		transform.localPosition= Player.transform.position + offset;
		offset.y= offset.y + temp.y/400;
		offset.z= offset.z - temp.y/400;
		Player.transform.localScale = temp;
	}
}
