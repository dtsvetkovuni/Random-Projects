﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

	public class PlayerController : MonoBehaviour {
	public bool end=false;
	public float speed;
	public Text countText;
	public Text winText;
	public Text timerText;
	Vector3 temp;

	private float startTime;
    private Rigidbody rb;
    private int count;

    void Start ()
{
        rb = GetComponent<Rigidbody>();
        count = 0;
        SetCountText ();
        winText.text = "";
	startTime=Time.time;
}
	void Update()
{
	if (Input.GetKeyDown(KeyCode.R))
      Application.LoadLevel("minigame");
	if(!end)
{
	float t = Time.time - startTime;
	string minutes = ((int) t/60).ToString();
	string seconds = (t % 60).ToString("f2");
	timerText.text= minutes + ":" + seconds;
	temp=transform.localScale;
	temp.x+= Time.deltaTime/10;
	temp.y+= Time.deltaTime/10;
	temp.z+= Time.deltaTime/10;
	transform.localScale=temp;
	//*if(count) trigger on count change and add size
}	
}
    void FixedUpdate ()
{
        float moveHorizontal = Input.GetAxis ("Horizontal");
        float moveVertical = Input.GetAxis ("Vertical");

        Vector3 movement = new Vector3 (moveHorizontal, 0.0f, moveVertical);

        rb.AddForce (movement * speed);
}

    void OnTriggerEnter(Collider other) 
{
        if (other.gameObject.CompareTag ( "Pick Up"))
        {
            other.gameObject.SetActive (false);
            count = count + 1;
            SetCountText ();
        }
    }

    void SetCountText ()
    {
        countText.text = "Score: " + count.ToString ();
        if (count >= 17)
        {
	end=true;
	timerText.color=Color.red;
            winText.text = "You Win!" ;
        }
    }
}